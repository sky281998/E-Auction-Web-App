from django.apps import AppConfig


class AuctionConfig(AppConfig):
    name = 'auction'
